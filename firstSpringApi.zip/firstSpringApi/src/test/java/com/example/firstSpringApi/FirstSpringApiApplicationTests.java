package com.example.firstSpringApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
